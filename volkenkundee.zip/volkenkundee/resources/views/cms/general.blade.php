@extends('layouts.cmsLayout')

@section('mainContent')
    <h1>General settings</h1>
@endsection