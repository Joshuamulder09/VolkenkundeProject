@extends('layouts.cmsLayout')

@section('mainContent')

    <script>
        function textAreaAdjust(o) {
            o.style.height = "1px";
            o.style.height = (25+o.scrollHeight)+"px";
        }
    </script>


    <h1>Edit page: <u>{{ $title }}</u></h1>
    <br/>
    <form method="post" action="/editpage/{{ $id }}">
        <input placeholder="Page Name:" type="text" name="pageName" value="{{ $title }}">

        <br /><br />

        <input type="hidden" name="_token" value="{{ csrf_token() }}">

        <input type="file" name="fileToUpload" id="fileToUpload">

        <br /><br />

        <textarea onfocus="textAreaAdjust(this)" placeholder="Page Content:" rows="10" cols="80" name="pageContent">{{ $content }}</textarea>

        <br /><br />

        <input type="submit" value="Submit" />

        <br /><br />

        <p>Go to the page <a>click here</a></p>
    </form>
@endsection