@extends('layouts.cmsLayout')

@section('mainContent')
    <h1>Add page</h1>
    <br/>
    <form method="post" action="/addpage">
        <input placeholder="Page Name:" type="text" name="pageName">

        <br /><br />

        <input type="hidden" name="_token" value="{{ csrf_token() }}">

        <input type="file" name="fileToUpload" id="fileToUpload">

        <br />

        <textarea placeholder="Page Content:" rows="10" cols="80" name="pageContent"></textarea>

        <br /><br />

        <input type="radio" name="navigationPlace" value="NULL" checked>Nieuwe parent page<br />
        @foreach($pages as $x)
            @if($x->page_parent_id == NULL)
                <input type="radio" name="navigationPlace" value="{{ $x->page_id }}"> {{ $x->page_name }} <br />
            @endif
        @endforeach

        <br /><br />

        <input type="submit" value="Submit" />
    </form>
@endsection