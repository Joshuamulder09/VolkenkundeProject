<!DOCTYPE html>
<html lang="nl">

<head>
    <link rel="shortcut icon" href="/images/favicon.png" type="image/vnd.microsoft.icon">
    <title>Back end</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/cms.css">
</head>

<body>
<header>
    <div class="left">
        <a target="_blank" title="Vitis Volkenkunde" href="/">Visite website</a>
    </div>

    <div class="right">
        <p>Loged in as: <b>{{ Auth::user()->name }}</b> | <a title="Logout" href="/logout">Logout</a></p>
    </div>
</header>

<main>
    <div class="sidebar">
        <nav>
            <ul>
                <li class="{{ Request::path() == 'pages' ? 'activeLi' : '' }}"><a title="Pages" href="/pages">Pages</a></li>
                <li class="{{ Request::path() == 'users' ? 'activeLi' : '' }}"><a title="Users" href="/users">Users</a></li>
                <div class="seperator"></div>
                <li class="{{ Request::path() == 'general_settings' ? 'activeLi' : '' }}"><a title="General settings" href="/general_settings">General settings</a></li>
            </ul>
        </nav>
    </div>

    <div class="content">
        @yield('mainContent')
    </div>
</main>

<footer>

</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>

</html>