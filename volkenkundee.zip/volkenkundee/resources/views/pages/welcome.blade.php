@extends('layouts.pageStandard')

@section('footer-content-1')

    @endsection