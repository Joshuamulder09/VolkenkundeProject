@extends('layouts.pageLayout')

@section('mainTitle')
    <h1 class="node-page-title">{{ $title }}</h1>
@endsection

@section('mainContent')
    <p>{!! html_entity_decode($content) !!}</p>
@endsection