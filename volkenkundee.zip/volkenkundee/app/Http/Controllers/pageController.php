<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

class pageController extends Controller {

    public function home() {

        $x = DB::table('pages')->get();
        $title = "Home";

        $carousel = DB::table('carousels')->get();
        $carousel_count = DB::table('carousels')->count();

        return view('pages.welcome', [
            'carousel'=>$carousel,
            'carousel_count'=>$carousel_count,
            'menu' =>$x,
            'title' => $title
        ]);
    }

    public function pageStandard ($route) {

        $x = DB::table('pages')->get();

        $title = DB::table('pages')->where('page_routes', $route)->value('page_name');
        $content = DB::table('pages')->where('page_routes', $route)->value('page_content');

        return view('pages.page', [
            'menu' =>  $x,
            'title' => $title,
            'content' => $content
        ]);
    }
}
