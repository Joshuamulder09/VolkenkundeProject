<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
Use App\User;
Use App\Role;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class cmsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

//    =====================================
//    Add the pages
//    =====================================

    public function addPage()
    {

        $pages = DB::table('pages')->get();

        return view('cms.addPage', [
            'pages' => $pages
        ]);
    }

    public function realaddPage()
    {

        $page_routes = strtolower(str_replace(' ', '_', $_POST['pageName']));

        DB::table('pages')->insert(array(

            'page_name' => $_POST['pageName'],
            'page_content' => $_POST['pageContent'],
            'page_routes' => $page_routes,
            'page_parent_id' => $_POST['navigationPlace']

        ));

        return redirect('addpage');
    }



//    =====================================
//    Delete pages
//    =====================================

    public function deletepages()
    {

        DB::table('pages')->where('page_id', '=', $_POST['id'])->delete();

        echo $_POST['id'];

        return redirect('/pages');
    }



//    =====================================
//    Pages
//    =====================================

    public function pages()
    {

        $pages = DB::table('pages')->orderby('page_name', 'asc')->get();

        return view('cms.pages', [
            'pages' => $pages
        ]);
    }



//    =====================================
//    edit the pages
//    =====================================

    public function editPage($id)
    {

        $title = DB::table('pages')->where('page_id', $id)->value('page_name');
        $content = DB::table('pages')->where('page_id', $id)->value('page_content');
        $route = DB::table('pages')->where('page_id', $id)->value('page_routes');

        return view('cms.editPage', [
            'title' => $title,
            'content' => $content,
            'id' => $id,
            'route' => $route
        ]);
    }

    public function realeditPage($id)
    {

        $page_routes = strtolower(str_replace(' ', '_', $_POST['pageName']));

        DB::table('pages')
            ->where('page_id', $id)
            ->update([
                'page_name' => $_POST['pageName'],
                'page_routes' => $page_routes,
                'page_content' => $_POST['pageContent']
            ]);

        return redirect('/editpage/' . $id);
    }


//    =====================================
//    General
//    =====================================

    public function general()
    {
        return view('cms.general');
    }



//    =====================================
//    Users
//    =====================================
    public function users()
    {
        $users = DB::table('users')->get();
        return view('cms.users', [
            'users' => $users,
        ]);
    }


    public function postAdminAssignRoles(Request $request)
    {
        $user = User::where('email', $request['email'])->first();
        $user->roles()->detach();
        if ($request['role_user']) {
            $user->roles()->attach(Role::where('name', 'User')->first());
        }
        if ($request['role_author']) {
            $user->roles()->attach(Role::where('name', 'Author')->first());
        }
        if ($request['role_admin']) {
            $user->roles()->attach(Role::where('name', 'Admin')->first());
        }
        return redirect()->back();
    }


}
