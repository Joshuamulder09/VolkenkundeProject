<!DOCTYPE html>
<html lang="nl">

<head>
    <link rel="shortcut icon" href="/images/favicon.png" type="image/vnd.microsoft.icon">
    <title><?php echo e($title); ?> - Volkenkunde</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/volkenkunde.css">
</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="/"><img src="images/logo.png"></a>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav navbar-right">
                                <?php foreach($menu as $x): ?>
                                    <?php if($x->page_parent_id == NULL): ?>
                                        <li>
                                        <li class="dropdown">
                                            <a href="/<?php echo e($x->page_routes); ?>" class="dropdown-toggle"><?php echo e($x->page_name); ?><span class="caret"></span></a>
                                            <ul class="dropdown-menu">
                                                <?php foreach($menu as $y): ?>
                                                    <?php if($x->page_id == $y->page_parent_id): ?>
                                                        <li><a href="/<?php echo e($y->page_routes); ?>"><?php echo e($y->page_name); ?></a></li>
                                                    <?php endif; ?>
                                                <?php endforeach; ?>
                                            </ul>
                                        </li>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!-- /.container-fluid -->
                </nav>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="row">
                <?php echo $__env->yieldContent('mainTitle'); ?>
            </div>
            <div class="row">
                <div class="col-md-3 col-lg-3">

                </div>
                <div class="col-md-6 col-lg-6">
                    <?php echo $__env->yieldContent('mainContent'); ?>
                </div>
                <div class="col-md-3 col-lg-3">
                    <h3 class="h3sidebar">Nieuwsbrief</h3>
                    <a href="/inschrijven"><img src="images/Banner-SidebarVOlkenkunde.gif"></a>
                    <br />
                    <br />
                    <br />
                    <h3 class="h3sidebar">Activiteiten agenda</h3>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 footer-col">
                    <img src="images/logo.png">
                </div>
                <div class="col-lg-3 col-md-3 footer-col">
                    <h3>BEZOEKADRES</h3>
                    <p>Steenstraat 1, Leiden</p>
                </div>
                <div class="col-lg-3 col-md-3 footer-col">
                    <h3>OPENINGSTIJDEN</h3>
                    <p>Dinsdag tot en met zondag</p>
                    <p>10 - 17 uur</p>
                </div>
                <div class="col-lg-3 col-md-3 footer-col">
                    <h3>CONTACT</h3>
                    <p>info@volkenkunde.nl</p>
                    <p>+31 (0)88 0042800</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>


</body>


</html>