<?php $__env->startSection('mainContent'); ?>
    <h1>Add page</h1>
    <br/>
    <form method="post" action="/addpage">
        <input placeholder="Page Name:" type="text" name="pageName">

        <br /><br />

        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

        <input type="file" name="fileToUpload" id="fileToUpload">

        <br />

        <textarea placeholder="Page Content:" rows="10" cols="80" name="pageContent"></textarea>

        <br /><br />

        <input type="radio" name="navigationPlace" value="NULL" checked>Nieuwe parent page<br />
        <?php foreach($pages as $x): ?>
            <?php if($x->page_parent_id == NULL): ?>
                <input type="radio" name="navigationPlace" value="<?php echo e($x->page_id); ?>"> <?php echo e($x->page_name); ?> <br />
            <?php endif; ?>
        <?php endforeach; ?>

        <br /><br />

        <input type="submit" value="Submit" />
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cmsLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>