<?php $__env->startSection('mainContent'); ?>

    <script>
        function textAreaAdjust(o) {
            o.style.height = "1px";
            o.style.height = (25+o.scrollHeight)+"px";
        }
    </script>


    <h1>Edit page: <u><?php echo e($title); ?></u></h1>
    <br/>
    <form method="post" action="/editpage/<?php echo e($id); ?>">
        <input placeholder="Page Name:" type="text" name="pageName" value="<?php echo e($title); ?>">

        <br /><br />

        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

        <input type="file" name="fileToUpload" id="fileToUpload">

        <br /><br />

        <textarea onfocus="textAreaAdjust(this)" placeholder="Page Content:" rows="10" cols="80" name="pageContent"><?php echo e($content); ?></textarea>

        <br /><br />

        <input type="submit" value="Submit" />

        <br /><br />

        <p>Go to the page <a>click here</a></p>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cmsLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>