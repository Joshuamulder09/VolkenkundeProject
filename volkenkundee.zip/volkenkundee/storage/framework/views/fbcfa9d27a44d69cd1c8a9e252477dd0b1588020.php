<?php $__env->startSection('jeOma'); ?>
    <h1>Delete page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cmsLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>