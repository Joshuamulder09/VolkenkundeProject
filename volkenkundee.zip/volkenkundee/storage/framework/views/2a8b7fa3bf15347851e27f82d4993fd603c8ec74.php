<!DOCTYPE html>
<html lang="nl">

    <head>
        <link rl="shortcut icon" href="/images/favicon.png" type="image/vnd.microsoft.icon">
        <title><?php echo e($title); ?> - Volkenkunde</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/volkenkunde.css">
    </head>

    <body>

    <div id="fb-root"></div>
    <script>(function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/nl_NL/sdk.js#xfbml=1&version=v2.5";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

        <header>
            <div class="container">
                <div class="row">
                    <nav class="navbar navbar-default">
                        <div class="container-fluid">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="/"><img src="images/logo.png"></a>
                            </div>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <?php foreach($menu as $x): ?>
                                        <?php if($x->page_parent_id == NULL): ?>
                                            <li>
                                                <li class="dropdown">
                                                    <a href="/<?php echo e($x->page_routes); ?>" class="dropdown-toggle"><?php echo e($x->page_name); ?><span class="caret"></span></a>
                                                <ul class="dropdown-menu">
                                                    <?php foreach($menu as $y): ?>
                                                        <?php if($x->page_id == $y->page_parent_id): ?>
                                                            <li><a href="/<?php echo e($y->page_routes); ?>"><?php echo e($y->page_name); ?></a></li>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                </ul>
                                                </li>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div><!-- /.navbar-collapse -->
                        </div><!-- /.container-fluid -->
                    </nav>
                </div>
            </div>
        </header>
        <main>
                <div class="row">
                    <!-- Start Carousel -->
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <?php for($i = 0; $i < $carousel_count; $i++): ?>
                                    <!-- Gives first item a class active -->
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($i); ?>" class="
                                        <?php if($i == 0): ?>
                                    active
                                <?php endif; ?>
                                    "></li>
                            <?php endfor; ?>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <!-- Moet nog uitvogelen om eerste item een active class te geven -->
                            <?php foreach($carousel as $x): ?>
                                <div class="item
                                                <?php if($x->carousel_id == 1): ?>
                                        active
                                <?php endif; ?>
                                        ">
                                    <img src="images/<?php echo e($x->carousel_img); ?>" />
                                    <div class="carousel-caption">
                                        <p><?php echo e($x->carousel_text); ?></p>
                                        <h1><?php echo e($x->carousel_title); ?></h1>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <!-- End Carousel -->
                </div>
            
            <div class="container">

                <div class="row row-50px">
                    <div class="col-md-4">
                        <img src="images/Nieuwsbrief-Did-you-know-234x200_0.jpg">
                        <div class="vakje_foto_home"><a href="">Nieuwsbrief</a></div>
                    </div>
                    <div class="col-md-4">
                        <img src="images/Openingstijden-Did-you-know-234x200.jpg">
                        <div class="vakje_foto_home"><a href="">Openingstijden en prijzen</a></div>
                    </div>
                    <div class="col-md-4">
                        <img src="images/Did_you_know_Vrienden.jpg">
                        <div class="vakje_foto_home"><a href="">Word vriend</a></div>
                    </div>
                </div> <!-- .row -->

                <div class="row row-50px">
                    <div class="col-md-9 col-lg-9">
                        <div class="col-md-12 col-lg-12">
adf
                        </div>
                    </div> <!-- .col-md-9 -->

                    <div class=".col-md-3 col-lg-3">
                        <a class="twitter-timeline" href="https://twitter.com/volkenkunde" data-widget-id="714796619506515968">Tweets door @volkenkunde</a>
                        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

                        <div class="fb-page" data-href="https://www.facebook.com/volkenkunde/" data-tabs="timeline" data-height="600" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/volkenkunde/"><a href="https://www.facebook.com/volkenkunde/">Museum Volkenkunde</a></blockquote></div></div>

                    </div> <!-- .col-md-3 -->
                </div> <!-- .row -->

            </div> <!-- .container -->
            
        </main>
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 footer-col">
                        <img src="images/logo.png">
                    </div>
                    <div class="col-lg-3 col-md-3 footer-col">
                        <h3>BEZOEKADRES</h3>
                        <p>Steenstraat 1, Leiden</p>
                    </div>
                    <div class="col-lg-3 col-md-3 footer-col">
                        <h3>OPENINGSTIJDEN</h3>
                        <p>Dinsdag tot en met zondag</p>
                        <p>10 - 17 uur</p>
                    </div>
                    <div class="col-lg-3 col-md-3 footer-col">
                        <h3>CONTACT</h3>
                        <p>info@volkenkunde.nl</p>
                        <p>+31 (0)88 0042800</p>
                    </div>
                </div>
            </div>
        </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>


    </body>


</html>