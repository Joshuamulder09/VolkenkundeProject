<?php $__env->startSection('mainContent'); ?>
    <h1>Pages</h1>
    <br />
    <br />
    <h3><a title="Add a new page" href="addpage">Click here to add a new page!!</a></h3>
    <br />
    <br />
    <?php foreach($pages as $x): ?>
        <h4>
            <a href="editpage/<?php echo e($x->page_id); ?>">EDIT</a>-
            <form method="post" action="/pages">
                <input name="id" type="hidden" value="<?php echo e($x->page_id); ?>" checked/>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <button type="submit">DELETE</button>
            </form> - <?php echo e($x->page_name); ?>

        </h4><br />
    <?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cmsLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>