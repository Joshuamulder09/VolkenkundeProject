<?php $__env->startSection('mainTitle'); ?>
    <h1 class="node-page-title"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainContent'); ?>
    <p><?php echo html_entity_decode($content); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pageLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>